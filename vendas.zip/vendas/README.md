# Vendas — Importação e Normalização de Dados

Aplicação web desenvolvida para o teste técnico, com o objetivo de receber um arquivo de vendas separado por TAB, interpretar os dados, normalizá-los em um banco relacional e apresentar a receita bruta das vendas importadas.

## Sobre o projeto

A aplicação permite:

- Fazer upload de arquivos `.tab`;
- Interpretar os dados separados por tabulação;
- Normalizar compradores, comerciantes e itens;
- Armazenar as informações em um banco de dados relacional;
- Registrar cada venda relacionando as entidades normalizadas;
- Calcular a receita bruta (`item price × purchase count`);
- Visualizar os registros importados e o total acumulado.

A estrutura foi pensada para manter as responsabilidades separadas e deixar o fluxo de importação simples de entender:

```text
Arquivo .tab
    ↓
Parser
    ↓
Normalização
    ↓
Banco relacional
    ↓
Consulta das vendas
    ↓
Receita bruta + registros importados
```

---

## Tecnologias

- **Next.js**
- **React**
- **TypeScript**
- **Prisma**
- **SQLite**
- **Tailwind CSS**

---

## Estrutura do projeto

```text
src/
├── app/
│   ├── actions.ts       # Server Action responsável pela importação
│   ├── globals.css
│   ├── layout.tsx
│   └── page.tsx         # Página principal e listagem das vendas
│
├── components/
│   └── UploadForm.tsx   # Formulário de upload
│
└── lib/
    ├── prisma.ts        # Instância do Prisma Client
    └── tsvParser.ts     # Leitura e interpretação do arquivo TAB

prisma/
└── schema.prisma        # Modelo relacional do banco
```

---

## Modelagem

Os dados recebidos no arquivo são separados em entidades para evitar a repetição das informações.

### Entidades

```text
Purchaser
   │
   └── Sale
          ├── Item
          └── Merchant
```

### Purchaser

Representa o comprador da venda.

### Merchant

Representa o comerciante e seu endereço.

### Item

Representa o produto vendido e seu preço.

### Sale

Representa a venda e mantém os relacionamentos com:

- comprador;
- item;
- comerciante;
- quantidade comprada.

As entidades possuem relacionamentos definidos no Prisma e as informações são persistidas utilizando transação durante a importação.

---

## Formato esperado do arquivo

A aplicação espera um arquivo com cabeçalho e as seguintes colunas, nesta ordem:

```text
purchaser name	item description	item price	purchase count	merchant address	merchant name
```

O arquivo deve ser separado por **TAB (`\t`)**.

Exemplo:

```text
John Doe	Red Chair	10.00	2	123 Main St	Store A
Jane Doe	Blue Table	25.00	1	456 Oak St	Store B
```

Um arquivo de exemplo está disponível no material fornecido para o teste.

---

## Receita bruta

A receita bruta de cada venda é calculada utilizando:

```text
item price × purchase count
```

Por exemplo:

```text
Preço:      $10.00
Quantidade: 2

Subtotal:   $20.00
```

Após a importação, a aplicação apresenta:

- A receita bruta referente ao arquivo enviado;
- A quantidade de vendas importadas;
- A receita bruta acumulada dos registros armazenados;
- Os registros das vendas no banco.

---

## Como executar

### Pré-requisitos

Antes de começar, certifique-se de ter instalado:

- Node.js
- npm

### 1. Instalar as dependências

```bash
npm install
```

### 2. Configurar o banco

Crie um arquivo `.env` na raiz do projeto:

```env
DATABASE_URL="file:./dev.db"
```

### 3. Criar/atualizar o banco

Execute:

```bash
npx prisma migrate dev
```

### 4. Executar em desenvolvimento

```bash
npm run dev
```

Depois, acesse:

```text
http://localhost:3000
```

---

## Build de produção

Para gerar o build:

```bash
npm run build
```

Depois:

```bash
npm start
```

---

## Fluxo de utilização

1. Acesse a aplicação.
2. Selecione o arquivo `.tab`.
3. Clique em **Enviar e Importar**.
4. O arquivo será interpretado pelo parser.
5. Os dados serão normalizados e persistidos no banco.
6. A receita bruta do arquivo será apresentada.
7. Os registros importados poderão ser visualizados na tabela.

---

## Decisões de implementação

### Parser separado da regra de persistência

A leitura do arquivo foi isolada em:

```text
src/lib/tsvParser.ts
```

Dessa forma, a responsabilidade de interpretar o arquivo fica separada da responsabilidade de persistir os dados.

### Server Action para importação

A importação é executada no servidor através de uma Server Action.

Isso permite que o processamento do arquivo e o acesso ao banco permaneçam no lado do servidor.

### Transação no banco

A importação utiliza uma transação do Prisma para que as operações de persistência sejam tratadas como uma única operação.

A ideia é evitar que uma falha durante a importação deixe o banco em um estado parcialmente atualizado.

---

## Comandos disponíveis

```bash
# Instalar dependências
npm install

# Rodar em desenvolvimento
npm run dev

# Executar lint
npm run lint

# Gerar build
npm run build

# Rodar aplicação em produção
npm start
```

---

## Observações

Este projeto foi desenvolvido como solução para um teste técnico, priorizando:

- Clareza do código;
- Separação de responsabilidades;
- Modelagem relacional;
- Simplicidade de execução;
- Utilização de tecnologias de código aberto.