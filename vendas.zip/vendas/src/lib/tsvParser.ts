export interface ParsedSaleRow {
  purchaserName: string;
  itemDescription: string;
  itemPrice: number;
  purchaseCount: number;
  merchantAddress: string;
  merchantName: string;
}

export function parseTabFile(content: string): ParsedSaleRow[] {
  // Trata quebras de linha Unix (\n) e Windows (\r\n)
  const lines = content.trim().split(/\r?\n/);

  // Se o arquivo tiver apenas o cabeçalho ou estiver vazio
  if (lines.length <= 1) return [];

  // Pula a primeira linha (cabeçalho)
  const dataLines = lines.slice(1);

  return dataLines
    .filter((line) => line.trim().length > 0)
    .map((line) => {
      const [
        purchaserName,
        itemDescription,
        itemPrice,
        purchaseCount,
        merchantAddress,
        merchantName,
      ] = line.split("\t").map((col) => col?.trim() ?? "");

      return {
        purchaserName,
        itemDescription,
        itemPrice: parseFloat(itemPrice) || 0,
        purchaseCount: parseInt(purchaseCount, 10) || 0,
        merchantAddress,
        merchantName,
      };
    });
}