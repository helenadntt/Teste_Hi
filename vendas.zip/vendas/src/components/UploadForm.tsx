"use client";

import { useState } from "react";
import { uploadSalesFile } from "@/app/actions";

export default function UploadForm() {
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<{
    success?: boolean;
    error?: string;
    totalRows?: number;
    fileGrossIncome?: number;
  } | null>(null);

  async function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setLoading(true);
    setResult(null);

    const formData = new FormData(event.currentTarget);
    const res = await uploadSalesFile(formData);

    setResult(res);
    setLoading(false);

    if (res.success) {
      (event.target as HTMLFormElement).reset();
    }
  }

  return (
    <div className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-xl p-6 shadow-sm mb-8">
      <h2 className="text-xl font-semibold mb-4 text-zinc-900 dark:text-zinc-100">
        Importar Arquivo de Vendas (.tab)
      </h2>

      <form onSubmit={handleSubmit} className="flex flex-col gap-4">
        <label className="flex flex-col gap-2 text-sm text-zinc-600 dark:text-zinc-400">
          <span>Selecione o arquivo delimitado por tabulações:</span>
          <input
            type="file"
            name="file"
            accept=".tab,.tsv,.txt"
            required
            className="file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-semibold file:bg-zinc-800 file:text-zinc-100 hover:file:bg-zinc-700 cursor-pointer border border-zinc-300 dark:border-zinc-700 rounded-md p-2 bg-transparent text-zinc-800 dark:text-zinc-200"
          />
        </label>

        <button
          type="submit"
          disabled={loading}
          className="self-start px-5 py-2.5 bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white font-medium rounded-lg transition-colors cursor-pointer"
        >
          {loading ? "Processando e Normalizando..." : "Enviar e Importar"}
        </button>
      </form>

      {result?.error && (
        <div className="mt-4 p-4 bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900 text-red-700 dark:text-red-300 rounded-lg text-sm">
          {result.error}
        </div>
      )}

      {result?.success && (
        <div className="mt-4 p-4 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-900 text-emerald-800 dark:text-emerald-300 rounded-lg">
          <p className="font-semibold text-base mb-1">
            Arquivo processado com sucesso!
          </p>
          <p className="text-sm">
            Linhas importadas: <strong>{result.totalRows}</strong>
          </p>
          <p className="text-lg font-bold mt-2">
            Receita Bruta do Arquivo (Gross Income):{" "}
            <span className="text-emerald-600 dark:text-emerald-400">
              {new Intl.NumberFormat("en-US", {
                style: "currency",
                currency: "USD",
              }).format(result.fileGrossIncome || 0)}
            </span>
          </p>
        </div>
      )}
    </div>
  );
}