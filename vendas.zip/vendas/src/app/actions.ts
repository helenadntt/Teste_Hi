"use server";

import { prisma } from "@/lib/prisma";
import { parseTabFile } from "@/lib/tsvParser";
import { revalidatePath } from "next/cache";

export async function uploadSalesFile(formData: FormData) {
  try {
    const file = formData.get("file") as File;

    if (!file || file.size === 0) {
      return { success: false, error: "Selecione um arquivo .tab válido." };
    }

    const content = await file.text();
    const rows = parseTabFile(content);

    if (rows.length === 0) {
      return {
        success: false,
        error: "O arquivo enviado não possui registros válidos.",
      };
    }

    let fileGrossIncome = 0;

    // Garante atomicidade: salva tudo ou nada se falhar
    await prisma.$transaction(async (tx) => {
      for (const row of rows) {
        fileGrossIncome += row.itemPrice * row.purchaseCount;

        // Normalização: Comprador
        const purchaser = await tx.purchaser.upsert({
          where: { name: row.purchaserName },
          update: {},
          create: { name: row.purchaserName },
        });

        // Normalização: Comerciante
        const merchant = await tx.merchant.upsert({
          where: { name: row.merchantName },
          update: { address: row.merchantAddress },
          create: { name: row.merchantName, address: row.merchantAddress },
        });

        // Normalização: Item / Produto
        const item = await tx.item.upsert({
          where: { description: row.itemDescription },
          update: { price: row.itemPrice },
          create: { description: row.itemDescription, price: row.itemPrice },
        });

        // Venda (Relacionamento entre as entidades)
        await tx.sale.create({
          data: {
            purchaserId: purchaser.id,
            merchantId: merchant.id,
            itemId: item.id,
            purchaseCount: row.purchaseCount,
          },
        });
      }
    });

    revalidatePath("/");

    return {
      success: true,
      totalRows: rows.length,
      fileGrossIncome,
    };
  } catch (error) {
    console.error("Erro ao importar vendas:", error);
    return {
      success: false,
      error: "Ocorreu um erro ao processar e salvar o arquivo.",
    };
  }
}