import { prisma } from "@/lib/prisma";
import UploadForm from "@/components/UploadForm";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  // Busca todas as vendas com as relações normalizadas
  const sales = await prisma.sale.findMany({
    include: {
      purchaser: true,
      merchant: true,
      item: true,
    },
    orderBy: { createdAt: "desc" },
  });

  // Calcula o total acumulado de todas as vendas salvas
  const totalAccumulatedGross = sales.reduce(
    (acc, sale) => acc + sale.item.price * sale.purchaseCount,
    0
  );

  return (
    <main className="max-w-5xl mx-auto px-4 py-10 font-sans">
      <header className="mb-8">
        <h1 className="text-3xl font-extrabold text-zinc-900 dark:text-zinc-50 tracking-tight">
          Vendas
        </h1>
        <p className="text-zinc-600 dark:text-zinc-400 mt-1">
          Normalização relacional e cálculo de receita bruta de vendas.
        </p>
      </header>

      {/* Formulário de Upload */}
      <UploadForm />

      {/* Card com o Total Geral Acumulado no Banco */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
        <div className="p-5 border border-zinc-200 dark:border-zinc-800 rounded-xl bg-zinc-50 dark:bg-zinc-900/50">
          <span className="text-xs uppercase font-semibold text-zinc-500 tracking-wider">
            Total de Vendas Registradas
          </span>
          <p className="text-3xl font-bold mt-1 text-zinc-900 dark:text-zinc-100">
            {sales.length}
          </p>
        </div>

        <div className="p-5 border border-zinc-200 dark:border-zinc-800 rounded-xl bg-zinc-50 dark:bg-zinc-900/50">
          <span className="text-xs uppercase font-semibold text-zinc-500 tracking-wider">
            Receita Bruta Total Acumulada
          </span>
          <p className="text-3xl font-bold mt-1 text-blue-600 dark:text-blue-400">
            {new Intl.NumberFormat("en-US", {
              style: "currency",
              currency: "USD",
            }).format(totalAccumulatedGross)}
          </p>
        </div>
      </div>

      {/* Tabela de Vendas */}
      <section className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 rounded-xl p-6 shadow-sm overflow-hidden">
        <h2 className="text-xl font-semibold mb-4 text-zinc-900 dark:text-zinc-100">
          Registros no Banco de Dados
        </h2>

        {sales.length === 0 ? (
          <p className="text-zinc-500 text-sm">
            Nenhuma venda registrada ainda. Faça o upload do arquivo acima para
            começar.
          </p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm text-zinc-700 dark:text-zinc-300">
              <thead className="bg-zinc-100 dark:bg-zinc-800 text-zinc-900 dark:text-zinc-100 font-semibold border-b border-zinc-200 dark:border-zinc-700">
                <tr>
                  <th className="py-3 px-4">Comprador</th>
                  <th className="py-3 px-4">Item</th>
                  <th className="py-3 px-4">Preço Un.</th>
                  <th className="py-3 px-4">Qtd.</th>
                  <th className="py-3 px-4">Subtotal</th>
                  <th className="py-3 px-4">Comerciante</th>
                  <th className="py-3 px-4">Endereço</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-200 dark:divide-zinc-800">
                {sales.map((sale) => {
                  const subtotal = sale.item.price * sale.purchaseCount;
                  return (
                    <tr
                      key={sale.id}
                      className="hover:bg-zinc-50 dark:hover:bg-zinc-800/50"
                    >
                      <td className="py-3 px-4 font-medium text-zinc-900 dark:text-zinc-100">
                        {sale.purchaser.name}
                      </td>
                      <td className="py-3 px-4">{sale.item.description}</td>
                      <td className="py-3 px-4">
                        ${sale.item.price.toFixed(2)}
                      </td>
                      <td className="py-3 px-4">{sale.purchaseCount}</td>
                      <td className="py-3 px-4 font-semibold text-emerald-600 dark:text-emerald-400">
                        ${subtotal.toFixed(2)}
                      </td>
                      <td className="py-3 px-4">{sale.merchant.name}</td>
                      <td className="py-3 px-4 text-xs text-zinc-500">
                        {sale.merchant.address}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </main>
  );
}